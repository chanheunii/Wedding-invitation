# 모바일 청첩장 — 최종 검토용

## 실행
ZIP을 풀고 이 폴더를 Netlify Drop에 업로드하거나, 폴더에서 `python -m http.server 8000` 실행 후 http://localhost:8000 접속.
`index.html`을 파일 앱에서 직접 열면 일부 기능/공유 미리보기가 작동하지 않을 수 있습니다.

## 한 파일에서 내용 수정
`invitation-data.js`에서 날짜(weddingISO), 이름, 초대 문구(invitationLines), 주소/검색어, 계좌(accounts), 사진 경로(photos 및 gallery)를 변경합니다. 사진은 `assets/`, `photos/` 폴더에 저장되어 있습니다.
앨범 사진 교체는 해당 파일을 동일 이름으로 교체하면 됩니다. 파일 이름을 바꾸면 `gallery` 경로도 변경합니다.

## 지도
구글 지도 iframe 및 카카오/네이버 지도 검색 링크가 연결되어 있습니다. 지도 검색 결과가 실제 예식장인지 휴대폰에서 확인하세요.

## OG 공유 미리보기
`assets/share.jpg`가 들어 있습니다. 공유용 og:image는 실제 배포 URL이 확정되면 `index.html`의 og:image content를 `https://실제도메인/assets/share.jpg`로 변경해야 카카오톡 등에서 안정적으로 표시됩니다. 공유 캐시 갱신도 필요할 수 있습니다.

## 관리자 로그인
현재 청첩장에는 관리자 로그인 화면/서버가 없습니다. 방명록은 비활성화되어 있고 관리자 비밀번호/비밀키도 포함하지 않았습니다. 관리자 기능이 필요하면 Netlify Identity 등 별도 인증 서비스를 서버 측에서 연결해야 합니다.

## 미완료 확인 사항
- Safari iOS 및 Android Chrome 실기기 검증은 수행하지 못했습니다.
- 약도 이미지 파일은 제공된 v24.3 ZIP에 없습니다. 실제 지도 iframe은 있으나 오프라인 약도는 포함되지 않았습니다.
- 무료 주차 시간/제휴 주차장/버스 정보는 예식장에 최종 확인하세요.
- 실제 배포 주소를 알 수 없어 공개 URL 및 OG 이미지 절대 URL은 설정하지 않았습니다.


## 이번 최종 정적 검증
- VALIDATION_REPORT.json 참조. 이미지 파일 디코딩/파일 경로/JS 구문/민감정보 패턴 검사.
- Chromium에서 로컬 HTTP 및 file URL 탐색이 정책상 차단되어 실제 렌더링, 터치, 버튼 위치, Safari/Android 검증은 **미완료**.
- OG 이미지 절대 주소, 지도 외부 서비스 작동, 실제 하객 배포는 공개 배포 후 별도 확인 필요.
